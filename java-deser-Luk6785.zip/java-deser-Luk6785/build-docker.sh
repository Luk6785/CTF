#!/bin/bash
chal="${CHAL:-java-deser-luk6785}"
docker rm -f "$chal"
docker build --tag="$chal" .
docker run -p 1337:1337 --rm --name="${chal}" "${chal}"

# docker run -d -p 1337:1337 -p 8000:8000 -e JPDA_ADDRESS=8000 -e JPDA_TRANSPORT=dt_socket --name=java-deser-luk6785 java-deser-luk6785 /usr/local/tomcat/bin/catalina.sh jpda run